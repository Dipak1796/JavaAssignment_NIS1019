package com.nissan.app;

import java.util.Scanner;

public class Question_02 {
	//create y vaiable and assigning value
	private static int y=1673;

	public static void main(String[] args) {
		//Create accepting object
		Scanner sc=new Scanner(System.in);
		//accept user pin
		System.out.println("Enter your 4 digit pin");
		int pin=sc.nextInt();
		checkPin(pin);
		sc.close();

	}
	private static void checkPin(int pin){
		if(pin==y)
			System.out.println("Correct Pin You can Proceed....");
		else
			System.out.println("Please enter correct pin..");
	}

}
