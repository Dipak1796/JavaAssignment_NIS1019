package com.nissan.app;

import java.util.Scanner;

public class Question_03 {

	public static void main(String[] args) {


		Scanner sc=new Scanner(System.in);
		//Accept month from user
		System.out.println("Enter month number");
		int month=sc.nextInt();
		checkSeason(month);
		sc.close();

	}
	private static void checkSeason(int month)
	{
		if(month>0&&13>month)
		{
		if(month==1||month==2||month==12)
			System.out.println("Winter Season");
		else if(month>=3&&month<=5)
			System.out.println("Spring Season");
		else if(month>=6&&month<=8)
			System.out.println("Summer Season");
		else if(month>=9&&month<=11)
			System.out.println("Autumn Season");
		}
		else
			System.out.println("Enter valid month");
	}

}
