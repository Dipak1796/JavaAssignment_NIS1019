package com.nissan.app;

import java.util.Scanner;

public class Question_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		//accept number from user
		System.out.println("Enter Number");
		int input=sc.nextInt();
		createStructure(input);
		sc.close();
		
	}
	private static void createStructure(int input){
		
		for(int i=input;i>0;i--)
		{
			System.out.println();
			for(int j=0;j<i;j++)
			{
				System.out.print("*");
			}
		}
	}

}
