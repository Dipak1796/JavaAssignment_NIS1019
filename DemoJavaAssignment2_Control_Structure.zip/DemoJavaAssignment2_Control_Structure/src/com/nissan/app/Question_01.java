package com.nissan.app;

import java.util.Scanner;

public class Question_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		try{
		//Accept Customer type
		System.out.println("1.Domestic User\n2.Industry User");
		System.out.println("Enter your choise");
		int ch=sc.nextInt();
		boolean flag;
		switch(ch)
		{
		case 1 : flag=true;
		         System.out.println("Enter unit quantity");
		         int unit=sc.nextInt();
		         electricityBill(unit,flag);
				 break;
		case 2 :flag=false;
		         System.out.println("Enter unit quantity");
		         int unit1=sc.nextInt();
		         electricityBill(unit1,flag);
				break;
		}
		sc.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
	private static void electricityBill(int unit,boolean flag)
	{
		//Calculation of Total Bill
		if(flag)
		{
			System.out.println("Domestic User");
			if(unit<100)
				System.out.println("Total Bill :"+(unit*1));
			else if(unit>=100&&200>unit)
				System.out.println("Total Bill :"+(unit*1.5f));
			else if(unit>=200&&500>unit)
				System.out.println("Total Bill :"+(unit*2));
			else
				System.out.println("Total Bill :"+(unit*5));
				
		}
		else
		{
			System.out.println("Industry User");
			System.out.println("Total Bill :"+(unit*10));
		}
	}

}
