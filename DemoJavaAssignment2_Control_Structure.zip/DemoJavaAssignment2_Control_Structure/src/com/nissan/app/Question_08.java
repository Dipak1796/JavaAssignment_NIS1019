package com.nissan.app;

   
public class Question_08 {

	public static void main(String[] args) {
		Box b1=new Box(5,7,8);
		Box b2=new Box(6,9,12);
		
		b1.volumeCalFor8();
		b2.volumeCalFor8();

	}

}
