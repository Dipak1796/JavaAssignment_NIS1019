package com.nissan.app;

import java.util.Scanner;

public class Question_09 {

	public static void main(String[] args) {
		
		
		System.out.println(convertValue());
	}
	private static int convertValue()
	{
		
		Scanner sc=new Scanner(System.in);
		//accept real constant value
		System.out.println("Enter real constant value");
		float input=sc.nextFloat();
		
		return (int)input;
	}

}
