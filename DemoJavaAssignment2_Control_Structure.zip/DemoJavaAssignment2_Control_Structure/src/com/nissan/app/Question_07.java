package com.nissan.app;

import java.util.Scanner;
   
 class Box{
	 int width;
	 int height;
	 int depth;
	 
	 public Box(int width,int height,int depth)
	 {
		 this.width=width;
		 this.height=height;
		 this.depth=depth;
	 }
	 
	 public Box(){
		 
	 }
	 
	 public int volume(){
		 Scanner sc=new Scanner(System.in);
		 int volume=0;
		 try{
			 System.out.println("Enter the Width of Box");
			 width=sc.nextInt();
			 System.out.println("Enter the Depth of Box");
			 depth=sc.nextInt();
			 System.out.println("Enter the Height of Box");
			 height=sc.nextInt();
			 
			 volume=width*height*depth;
			
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }
		 sc.close();
		 return volume;
	 }
	 public int volumeCalFor8(){
		 
		 int volume=0;
		 try{
			 
			 
			 volume=width*height*depth;
			
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }
	
		 return volume;
	 }
 }

public class Question_07 {

	public static void main(String[] args) {
		Box b1=new Box();
		Box b2=new Box();
		
		b1.volume();
		b2.volume();

	}

}
