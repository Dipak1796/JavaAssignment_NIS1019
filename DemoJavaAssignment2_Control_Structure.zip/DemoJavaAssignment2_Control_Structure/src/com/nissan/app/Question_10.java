package com.nissan.app;

import java.util.Scanner;

public class Question_10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter month (1-12)");
		int month=sc.nextInt();
	
		System.out.println(	getMonthName(month));
		sc.close();
		

	}
	private static String getMonthName(int month)
	{
		if(month>12&&month<0){
		String [] arrMonth={"January","February","March","April",
				            "May","June","July","August","September",
				             "Octomber","November","December"};
		return arrMonth[month-1];
		}
		else
			return "Enter valid month";
	}
		
}
