package com.nissan.app;

import java.util.Scanner;

public class Question_05 {

	public static void main(String[] args) {
		
	
		printSyntax();

	}
	private static void printSyntax()
	{
		Scanner sc=new Scanner(System.in);
		int ch;
		do{
			System.out.println("1.if");
			System.out.println("2.switch");
			System.out.println("3.while");
			System.out.println("4.do while");
			System.out.println("5.for");
			System.out.println("6.Exit");
			System.out.println("============================\n\n");
			System.out.println("Enter your choise");
			ch=sc.nextInt();
			switch(ch){
			case 1 : System.out.println("if(condition)\n { statement } ");
			         break;
			case 2 :System.out.println("switch(choise){");
			        System.out.println(" case 1 : statement; \n}");
			        break;
			case 3 :System.out.println("while(condition){");
			        System.out.println("  statement; \n}");
			        break;
			case 4 :System.out.println("do{\n statement;");
			       	System.out.println("}while(condition)");
			       	break;
			case 5 :System.out.println("for(expression 1;boolean check; expression 2)");
			        break;
			
			case 6 :break;
			}
		}while(ch!=6);
		sc.close();
	}

}
