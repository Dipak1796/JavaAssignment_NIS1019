package com.nissan.app;

import java.util.Scanner;

public class DemoMonths {

	public static void main(String[] args) {
        //Calling method
		getInputFromUser();
	}
	
	private static void getInputFromUser(){
		
		char inputYesNo='n';
		do{
			Scanner sc=new Scanner(System.in);
			//accept month input
			System.out.println("Enter a month (1-12) :");
			int month=sc.nextInt();
			//accept year input
			System.out.println("Enter a Year :");
			int year=sc.nextInt();
			
			String monthName=getMonthName(month);
			//get days 
			int daysInMonth=getDaysInMonth(month);
			if(month==2&&checkLeapYear(year))
			{
				daysInMonth+=1;
			}
			
			System.out.println(monthName +" "+year+" days in month "+daysInMonth);
			
			
		}while(inputYesNo=='y'||inputYesNo=='Y');
	}
	
	private static String getMonthName(int month){
		
		String [] months={"January","February","March","April",
				          "May","June","July","August","September",
				          "Octomber","November","December"};
		return months[month-1];
	}
	
	private static int getDaysInMonth(int month)
	{
		if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)
			return 31;
		else if(month==4||month==6||month==9||month==11)
			return 30;
		else
		    return 28;
	}
	private static boolean checkLeapYear(int year)
	{
		//write logic for leap year
		if(year%4==0&&year%100!=0)
			return true;
		else if(year%400==0)
			return true;
		else
			return false;
	}

}
