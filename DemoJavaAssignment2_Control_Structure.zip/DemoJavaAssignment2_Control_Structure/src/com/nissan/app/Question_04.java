package com.nissan.app;

import java.util.Scanner;

public class Question_04 {

	public static void main(String[] args) {
		
		showSeason();

	}
	private static void showSeason(){
		 Scanner sc=new Scanner(System.in);
		 //showing month
		 System.out.println("1.January\n2.February\n3.March\n4.April\n5.May\n6.June\n7.July\n8.August\n9.Septeber\n10.Octomber\n11.November\n12.December");
		 //accept month input
		 System.out.println("Enter the month");
	        int choice=sc.nextInt();
	        
	        switch(choice)
	        {
	        case 1:
	            System.out.println("Winter Season");
	            break;
	        case 2:
	            System.out.println("Winter Season!");
	            break;
	        case 3:
	            System.out.println("Spring Season!");
	            break;
	        case 4:
	            System.out.println("Spring Season!");
	            break;
	        case 5:
	            System.out.println("Spring Season!");
	            break;
	        case 6:
	            System.out.println("Summer Season!");
	            break;
	        case 7:
	            System.out.println("Summer Season!");
	            break;
	        case 8:
	            System.out.println("Summer Season!");
	            break;
	        case 9:
	            System.out.println("Autumn Season!");
	            break;
	        case 10:
	            System.out.println("Autumn Season!");
	            break;
	        case 11:
	            System.out.println("Autumn Season!");
	            break;
	        case 12:
	            System.out.println("Winter Season!");
	            break;
	        default:
	            System.out.println("Invalid Choice");
	                
	        }
	        sc.close();
	}

}
