package com.nissan.app;

import java.util.Scanner;

public class Question_04 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Distance between two cities");
		int distance=sc.nextInt();
		convertDistance(distance);
		sc.close();

	}
	
	private static void convertDistance(int distance)
	{
		System.out.println("Distance in meter      :"+(distance*1000)+" m");
		System.out.println("Distance in feet       :"+(distance*1000*3.28084)+" ft");
		System.out.println("Distance in inches     :"+(distance*1000*39.37)+" in");
		System.out.println("Distance in centimeter :"+(distance*1000*10)+" cm");
	}

}
