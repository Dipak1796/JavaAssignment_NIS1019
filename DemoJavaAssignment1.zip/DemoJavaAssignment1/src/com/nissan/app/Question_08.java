package com.nissan.app;

import java.util.Scanner;

public class Question_08 {

	public static void main(String[] args) {


		Scanner sc=new Scanner(System.in);
		System.out.println("Enter i value");
		int i=sc.nextInt();
		System.out.println("Enter j value");
		int j=sc.nextInt();
		System.out.println("Before Interchange Position");
		System.out.println("i :"+i);
		System.out.println("j :"+j);
		
		i=i+j;
		j=i-j;
		i=i-j;
		
		System.out.println("After Interchange Position");
		System.out.println("i :"+i);
		System.out.println("j :"+j);
		sc.close();


	}

}
