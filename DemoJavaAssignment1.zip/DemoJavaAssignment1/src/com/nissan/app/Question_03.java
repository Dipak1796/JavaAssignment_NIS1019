package com.nissan.app;

import java.util.Scanner;

public class Question_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the First Number");
		int firstNumber=sc.nextInt();
		System.out.println("Enter the Second Number");
		int secondNumber=sc.nextInt();
		devideNumbers(firstNumber,secondNumber);
		
		sc.close();

	}
	
	private static void devideNumbers(int firstNumber,int secondNumber){
		try{
		int quotient=firstNumber/secondNumber;
		int remainder=firstNumber%secondNumber;
		System.out.println("Quotient :"+quotient);
		System.out.println("Remainder:"+remainder);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
