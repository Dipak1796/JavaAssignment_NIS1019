package com.nissan.app;

import java.util.Scanner;

public class Question_09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 5 digit number");
		int number=sc.nextInt();
		System.out.println("Sum of digit is :"+sumOfDigit(number));
		sc.close();

	}
	private static int sumOfDigit(int number){
		int sum=0;
		while(number>0)
		{
			sum+=number%10;
			number/=10;
		}
		return sum;
	}

}
