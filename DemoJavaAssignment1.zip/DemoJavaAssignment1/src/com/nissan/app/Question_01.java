package com.nissan.app;

import java.util.Scanner;

public class Question_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter quantity of Oranges :");
		int quantityOfOranges=sc.nextInt();
		System.out.println("Enter paying price");
		float price=sc.nextFloat();
		
		System.out.println("Orange Price is "+singleOrangePrice(quantityOfOranges,price));

		sc.close();
	}
	
	public static double singleOrangePrice(int quantityOfOranges, float price)
	{
		return price/quantityOfOranges;
	}

}
