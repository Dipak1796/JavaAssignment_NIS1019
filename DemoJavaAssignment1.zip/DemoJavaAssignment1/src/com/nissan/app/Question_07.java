package com.nissan.app;

import java.util.Scanner;

public class Question_07 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Raju's Basic Salary ");
		int basicSalary=sc.nextInt();
		System.out.println(String.format("Raju's Total Salary : %.2f",totalSalary(basicSalary)));
		sc.close();

	}
	private static double totalSalary(int salary)
	{
		float dearness=salary*0.4f;
		float houseRent=salary*0.2f;
		
		return salary+dearness+houseRent;
	}

}
