package com.nissan.app;

import java.util.Scanner;

public class Question_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the city temperature in Fahrenheit :");
		int temp=sc.nextInt();
		System.out.println(String.format("Temperature in Celcius : %.2f ",convertTemperature(temp)));
		sc.close();
	}
	
	private static double convertTemperature(int temp)
	{
		return (temp-32)*5.0/9.0;
	}

}
