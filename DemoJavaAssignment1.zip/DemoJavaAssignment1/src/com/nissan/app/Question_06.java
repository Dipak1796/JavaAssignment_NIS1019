package com.nissan.app;

import java.util.Scanner;

public class Question_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub,
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter i value");
		int i=sc.nextInt();
		System.out.println("Enter j value");
		int j=sc.nextInt();
		System.out.println("Before Interchange Position");
		System.out.println("i :"+i);
		System.out.println("j :"+j);
		
		int temp=i;
		i=j;
		j=temp;
		
		System.out.println("After Interchange Position");
		System.out.println("i :"+i);
		System.out.println("j :"+j);
		sc.close();

	}

}
