package com.nissan.app;

import java.util.Scanner;

public class Question_02 {

	public static void main(String[] args) {


		totalSpendPrice();

	}
	
	private static void totalSpendPrice()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter notebook prices");
		int notebookPrice=sc.nextInt();
		System.out.println("Enter magicpot price");
		int magicpotPrice=sc.nextInt();
		
		System.out.println("Total spending price : "+(notebookPrice+magicpotPrice));
		sc.close();
	}

}
